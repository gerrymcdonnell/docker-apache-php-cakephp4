<?
	echo phpinfo();
	echo "test myphp 123";
?>
